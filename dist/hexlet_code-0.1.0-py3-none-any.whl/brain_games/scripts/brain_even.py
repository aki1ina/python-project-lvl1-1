#!/usr/bin/env python
from brain_games import even_number


def main():
    even_number.even()
    

if __name__ == '__main__':
    main()
