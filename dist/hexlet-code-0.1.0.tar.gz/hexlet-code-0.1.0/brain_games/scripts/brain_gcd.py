#!/usr/bin/env python
from brain_games.games.divider import divider


def main():
    divider()


if __name__ == '__main__':
    main()
