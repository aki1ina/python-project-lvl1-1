#!/usr/bin/env python
from brain_games.games.progression import item_search


def main():
    item_search()


if __name__ == '__main__':
    main()
