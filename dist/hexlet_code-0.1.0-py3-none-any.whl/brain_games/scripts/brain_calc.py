#!/usr/bin/env python
from games import brain_calc


def main():
    brain_calc.calculator()


if __name__ == '__main__':
    main()
