#!/usr/bin/env python
import sys
from even_number import even


sys.path
def main():
    even()


if __name__ == '__main__':
    main()
